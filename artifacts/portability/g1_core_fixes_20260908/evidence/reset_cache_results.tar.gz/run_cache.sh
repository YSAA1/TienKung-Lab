#!/usr/bin/env bash
cd /home/nubot/phn_ws/t4_train/TienKung-Lab-g1-progress-ab-20260908
export CUDA_VISIBLE_DEVICES=0
export PYTHONDONTWRITEBYTECODE=1
timeout --signal=INT --kill-after=30s 300s bash scripts/nubot_run.sh /tmp/g1-runtime-contract-20260908/reset_cache_probe.py --headless --device cuda:0 --output /tmp/g1-runtime-contract-20260908/reset_cache.json > /tmp/g1-runtime-contract-20260908/reset_cache.log 2>&1
printf "%s\n" "$?" > /tmp/g1-runtime-contract-20260908/reset_cache.exit
