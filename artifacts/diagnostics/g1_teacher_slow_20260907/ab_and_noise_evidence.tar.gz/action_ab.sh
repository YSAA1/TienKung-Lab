#!/usr/bin/env bash
set -euo pipefail
root=/home/nubot/phn_ws/t4_train/TienKung-Lab-g1-portability-20260906
out=/tmp/g1_teacher_audit_20260907
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0
cd "$root"
for mode in current_effort legacy_radians; do
  export AUDIT_ACTION_MODE=$mode
  timeout -k 15s 900s bash scripts/nubot_run.sh "$out/action_ab_train.py" \
    --task g1_loco_teacher --num_envs 512 --seed 42 --max_iterations 200 --run_name "audit_$mode" --headless \
    >"$out/action_ab_${mode}.log" 2>&1
  echo "$mode completed" >>"$out/action_ab_exit.txt"
done
